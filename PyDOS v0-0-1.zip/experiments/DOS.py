"""
DOS

Description: A text-based operating system written in Python as a personal project
"""

# Variables - System and User

ROOTusername = "Admin"
ROOTpassword = "Admin"

username = [" "]
password = [" "]

debug_mode = 0 # 1 = Debug mode on (Skips Setup) 0 = Debug mode off (Runs Setup)

l = open("help.txt", "w")
l.seek(0)
help_list = l.read

# Python Imports

import pygame
pygame.init()
import random
import datetime
import sys

# System - Logs and start time

sysStart = datetime.datetime.now()

# Pygame - sounds

error = pygame.mixer.Sound("BassB.mp3")
boot = pygame.mixer.Sound("AcousticGuitarCHigh.mp3")

# Functions - SystemProcesses

def enviroment(rooton):
    if rooton == 1:
        print()
        v = input("c:/ROOT/ ")
        if v == "root":
            print("You're already in ROOT!")
            enviroment(1)
        elif v == "log out":
            print("Logging out of root...")
            enviroment(0)
        elif v == "shutdown":
            print("Shutting Down...")
            shutdown()
        elif v == "ping":
            v = input("What server do you want to ping? ")
            ms = str(random.randint(0, 10))
            mss = str(random.randint(0, 100))
            print("Pong from " + v + " with a delay of " + ms + "." + mss + " miliseconds.")
            enviroment(1)
        elif v == "sys":
            print("System: PyDOS")
            print("CPU: Simulated x86 core")
            print("Cores: 1")
            print("GPU: Simulated Onboard Graphincs Proccessor")
            print("RAM: 156 MB")
            print("Storage: 10 MB")
            print("System Uptime: Started on " + str(sysStart))
            enviroment(1)
        elif v == "add user":
            adduser(1)
        elif v == "mail":
            mail(1)
        elif v == "users":
            print(username)
            print(password)
            enviroment(1)
        elif v == "commands":
            print("Universal Commands: 'root' 'sys' 'add user' 'log out' 'shutdown' 'ping' 'mail' Root Only Commands: 'users'")
            enviroment(1)
        else:
            error.play()
            print("Invalid Command: '" + v + "'")
            enviroment(1)
    else:
        print()
        v = input("c:/ ")
        if v == "root":
            rootlogin()
        elif v == "log out":
            print("Logging out...")
            login()
        elif v == "shutdown":
            print("Shutting Down...")
            shutdown()
        elif v == "ping":
            v = input("What server do you want to ping? ")
            ms = str(random.randint(0, 10))
            mss = str(random.randint(0, 100))
            print("Pong from " + v + " with a delay of " + ms + "." + mss + " miliseconds.")
            enviroment(0)
        elif v == "sys":
            print("System: PyDOS")
            print("CPU: Simulated x86 core")
            print("Cores: 1")
            print("GPU: Simulated Nvidia Graphics Card")
            print("RAM: 156 MB")
            print("Storage: 10 MB")
            print("System Uptime: Started on " + str(sysStart))
            enviroment(0)
        elif v == "add user":
            adduser(0)
        elif v == "mail":
            mail(0)
        elif v == "commands":
            print(help_list)
            print("Universal Commands: 'root' 'sys' 'add user' 'log out' 'shutdown' 'ping' 'mail' Root Only Commands: 'users'")
            enviroment(0)
        else:
            error.play()
            print("Invalid Command: '" + v + "'")
            enviroment(0)
        
def rootlogin():
    print()
    v = input("What is the ROOT Username? ")
    e = input("What is the ROOT Password? ")
    if v == ROOTusername and e == ROOTpassword:
        root = 1
        enviroment(1)
    else:
        print("Invalid Credentials. Try again.")
        rootlogin()

def login():
    print()
    v = input("Enter your username. ")
    e = input("Enter your password. ")
    if v in username and e in password:
        enviroment(0)
    else:
        print("Invalid Credentials. Try again.")
        login()
            
def shutdown():
    pygame.time.wait(1000)
    print("[" + str(datetime.datetime.now()) + "] Clearing virtual RAM...")
    pygame.time.wait(5000)
    print("[" + str(datetime.datetime.now()) + "] Erasing virtual Memory...")
    pygame.time.wait(10000)
    print("[" + str(datetime.datetime.now()) + "] Clearing user data file...")
    clear = open("mail.txt", "w")
    clear.write(" ")
    clear.close()
    l.close
    pygame.time.wait(3000)
    print("[" + str(datetime.datetime.now()) + "] Stopping Process: DOS.py")
    sys.exit()

def adduser(rooton):
    v = input("What is the User's name? ")
    e = input("What is the User's password? ")
    
    if v not in username and e not in password:
        username.append(v)
        password.append(e)
        pygame.time.wait(500)
        print("User has been registered!")
        if rooton == 1:
            enviroment(1)
        else:
            enviroment(0)
    else:
        print("User is already registered!")
        if rooton == 1:
            enviroment(1)
        else:
            enviroment(0)

def mail(rooton):
    mail = open("mail.txt", "a")
    mail.write(" ")
    v = input("What is the receiver's email? ")
    mail.write("To: " + v)
    v = input("What is the Subject? ")
    mail.write(" Subject: " + v)
    v = input("What is the body? ")
    mail.write(" Body: " + v)
    print("Sending...")
    pygame.time.wait(3000)
    print("Send successful! Returning to terminal...")
    mail.close()
    if rooton == 1:
        enviroment(1)
    else:
        enviroment(0)

def commands(rooton):
    l = open("help.txt", "a")
    l.seek(0)
    help_list = l.read
    if rooton == 1:
        enviroment(1)
    else:
        enviroment(0)
# Startup

boot.play()
print(help_list)

print("[" + str(datetime.datetime.now()) + "] System Process: Starting up terminal...")
pygame.time.wait(1500)
print("[" + str(datetime.datetime.now()) + "] System Process: Terminal Running... beginning the setup...")
pygame.time.wait(2000)

if debug_mode == 0:
    print("Welcome to PyDOS, DOS written completely in Python!")
    print("It looks like you don't have an account, let's make one!")
    username.remove(" ")
    username.append(input("What will your username be? "))
    password.remove(" ")
    password.append(input("What will your password be? "))

print("Preparing your enviroment...")
pygame.time.wait(2000)
print("Ready!")

enviroment(0)